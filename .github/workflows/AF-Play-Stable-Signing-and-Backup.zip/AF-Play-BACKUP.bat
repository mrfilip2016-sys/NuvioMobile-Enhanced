@echo off
setlocal
set PKG=app.afplay.mobile.debug
set OUT=AF-Play-settings-backup.tar

echo.
echo AF Play - backup setari
echo Pachet: %PKG%
echo.

adb devices
echo.
echo Se salveaza shared_prefs, databases si files...
adb exec-out run-as %PKG% /system/bin/toybox tar -C /data/user/0/%PKG% -cf - shared_prefs databases files > "%OUT%"

if errorlevel 1 (
  echo.
  echo BACKUP ESUAT.
  echo Verifica USB debugging si ca AF Play este instalat.
  pause
  exit /b 1
)

echo.
echo Backup creat: %OUT%
echo NU dezinstala aplicatia pana nu vezi acest fisier.
pause
