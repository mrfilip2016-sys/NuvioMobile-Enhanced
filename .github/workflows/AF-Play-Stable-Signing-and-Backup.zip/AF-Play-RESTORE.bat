@echo off
setlocal
set PKG=app.afplay.mobile.debug
set IN=AF-Play-settings-backup.tar

if not exist "%IN%" (
  echo Lipseste %IN%
  pause
  exit /b 1
)

echo.
echo AF Play - restaurare setari
echo Instaleaza mai intai noul APK AF Play Stable, apoi continua.
echo.

adb devices
echo.
adb push "%IN%" /data/local/tmp/afplay-settings.tar
if errorlevel 1 (
  echo Push esuat.
  pause
  exit /b 1
)

adb shell "cat /data/local/tmp/afplay-settings.tar | run-as %PKG% /system/bin/toybox tar -C /data/user/0/%PKG% -xf -"
if errorlevel 1 (
  echo.
  echo RESTAURARE ESUATA.
  pause
  exit /b 1
)

adb shell rm -f /data/local/tmp/afplay-settings.tar

echo.
echo Restaurare terminata.
echo Inchide fortat AF Play si redeschide aplicatia.
pause
