AF Play - semnatura stabila si pastrarea setarilor

IMPORTANT
APK-urile v0.1 si v0.2 au fost construite pe runner-e GitHub diferite si au semnaturi debug diferite.
Cheia privata a semnaturii v0.1 nu mai exista, deci un APK nou nu poate actualiza acea instalare prin metoda normala Android.

SOLUTIA
1. Fa backup inainte de dezinstalare:
   - activeaza USB debugging
   - conecteaza Pixel-ul la un PC cu ADB
   - ruleaza AF-Play-BACKUP.bat
   - verifica sa existe AF-Play-settings-backup.tar

2. In GitHub:
   - urca af-play-stable-signing.yml in .github/workflows/ pe branch-ul enhanced
   - Actions -> AF Play Stable Signed APK -> Run workflow
   - descarca artifactul AF-Play-Stable-arm64

3. O SINGURA DATA:
   - dezinstaleaza vechiul AF Play
   - instaleaza APK-ul AF Play Stable

4. Restaureaza:
   - ruleaza AF-Play-RESTORE.bat din acelasi folder cu backup-ul

Din acel moment, workflow-ul pastreaza acelasi debug.keystore in GitHub Actions cache.
Build-urile urmatoare generate de acelasi workflow vor avea aceeasi semnatura si se vor instala ca update peste AF Play Stable.

Pachetul folosit de build-ul debug:
app.afplay.mobile.debug

Nota:
Cache-ul GitHub Actions este potrivit pentru acest flux de test/dezvoltare, nu pentru o cheie de release de productie.
Pentru distributie publica trebuie folosita o cheie release pastrata in GitHub Secrets.
